<?php


namespace Config;


class DbConfig
{
    const DB_HOST = 'localhost';
    const DB_NAME = 'booking';
    const DB_USER = 'root';
    const DB_PASS = '';
}