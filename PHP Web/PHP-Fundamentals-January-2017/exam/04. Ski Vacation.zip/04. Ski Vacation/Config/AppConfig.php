<?php


namespace Config;


class AppConfig
{
    const  FRONTEND_FOLDER_NAME = 'frontend';
}