<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sky vacation and stuff</title>
    <link rel="stylesheet" href="resourses/css/bootswatch.css">
</head>
<body>

<header class="container">
    <sectionclass="row">
        <?php include_once ('navigation.php');?>
    </section>
</header>