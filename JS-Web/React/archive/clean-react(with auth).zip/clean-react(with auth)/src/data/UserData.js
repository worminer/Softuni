const baseUrl = 'http://localhost:5000/auth';

const getOptions = () => ({
    method: 'POST',
    mode: 'cors',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
    }
  });
const  handleJsonResponce = res => res.json();

class UserData {
  static register (user) {
    let options = getOptions();
    options.body = JSON.stringify(user);
    return window.fetch(`${baseUrl}/signup`, options)
      .then(handleJsonResponce);
  }

  static login (user) {
    let options = getOptions();
    options.body = JSON.stringify(user);
    return window.fetch(`${baseUrl}/login`, options)
      .then(handleJsonResponce)
  }
}

export default UserData;