import React,{Component} from 'react';
import Router from '../../Router';

export default class Main extends Component{
  render () {
    return (
    <main className="container">
      <Router />
    </main>
    )
  }
}