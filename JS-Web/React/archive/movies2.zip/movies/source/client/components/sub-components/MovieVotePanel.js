import React from 'react';

export default class MovieVotePanel extends React.Component {
    render() {
        return (
            <div className="col-sm-4 col-xs-offset-8 list-group-item animated fadeIn vote">
                <div className="media">
                    <div className="media-body">
                        Hello from MovieVotePanel
                    </div>
                </div>
            </div>
        );
    }
}