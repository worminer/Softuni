import React from 'react';

export default class MovieCommentsPanel extends React.Component {
    render() {
        return (
            <div className="list-group">
                <h3 className="col-sm-3">Comments:</h3>
            </div>
        );
    }
}