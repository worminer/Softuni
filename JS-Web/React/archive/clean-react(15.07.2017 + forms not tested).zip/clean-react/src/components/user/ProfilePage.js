import React,{Component} from 'react';

export default class ProfilePage extends Component{
  render () {
    return (
      <section className="well">
        <h1>Welcome from ProfilePage</h1>

      </section>

    )
  }
}