const server = require('./source/server/server');

server();