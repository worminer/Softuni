import React,{Component} from 'react';

export default class HomePage extends Component{
  render () {
    return (
      <section className="well">
        <h1>Welcome from UserHomePage</h1>
        <h3>user will land on this page after login</h3>
      </section>

    )
  }
}