import React from 'react';

const NotFoundPage = () => (
    <div>
      <h1>test from NotFoundPage</h1>
      <h1>404 and stuff</h1>
    </div>
);

export default NotFoundPage;