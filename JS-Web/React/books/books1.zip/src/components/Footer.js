import React from 'react';

const Footer = () => (
    <div>
      <h1>test from Footer</h1>
    </div>
);

export default Footer;