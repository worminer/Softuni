import React from 'react';

const Footer = () => (
  <footer className="container-fluid">
    <section className="row text-center">
      <h1>Some footer Content here</h1>
    </section>
  </footer>
);

export default Footer;