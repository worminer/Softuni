#include <iostream>
using namespace std;

int main() {
    int n ;
    cout << "Specify end number N: " << endl;
    cin >> n ;

    for(int i = 1; i <= n; i++){
        cout << i << endl;
    }
    return 0;
}

